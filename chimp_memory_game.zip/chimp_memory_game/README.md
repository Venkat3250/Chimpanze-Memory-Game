
# 🧠 Chimpanzee Memory Game (Ayumu Test Clone)

A Python-based memory game inspired by Ayumu the chimpanzee's legendary memory skills.
Includes animation, robot mode, timing system, and sound effects.

## Run the Game
```
pip install pygame
python main.py
```

Place your custom sounds inside the `assets/` folder:
- click.wav
- correct.wav
- wrong.wav
